﻿using System;
using System.ComponentModel.DataAnnotations;


namespace OnlineBookStore.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [Required]
        [StringLength(50)]
        public string Author { get; set; }

        [Required]
        [Range(0.01, 999.99)]
        public decimal Price { get; set; }

        [Required]
        public DateTime PublishDate { get; set; }

        [Required]
        [StringLength(13)]
        
        public string ISBN { get; set; }
    }
}
