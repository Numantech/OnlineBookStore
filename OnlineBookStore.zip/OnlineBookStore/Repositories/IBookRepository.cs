﻿using OnlineBookStore.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OnlineBookStore.Repositories
{
    public interface IBookRepository
    {
        
        Task<IEnumerable<Book>> GetAllBooksAsync();
        Task<Book> GetBookByIdAsync(int id);
        Task CreateBookAsync(Book book);
        Task UpdateBookAsync(Book book);
        Task DeleteBookAsync(int id);
        Task<IEnumerable<Book>> SearchBooksAsync(string searchString);
    }
}

